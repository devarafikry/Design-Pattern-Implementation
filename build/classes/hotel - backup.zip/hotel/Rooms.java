package hotel;
public abstract class Rooms {
	String Rooms_str;
        String price;
	String duration;
        
	public void print()
	{
            System.out.println("   "+Rooms_str + "     " +price);
	}

}
