package hotel;
public class mainKomposisiHotel {
    public static void main(String[] args)
    {
        
        Sub_Rooms sub = new Sub_Rooms("Ruangan");
        Sub_Rooms sub1[][] = new Sub_Rooms[2][3];
        Sub_Rooms sub2 = new Sub_Rooms("Ruang Rapat");

        Item_Rooms item1 = new Item_Rooms("Suite Room");
        Item_Rooms item2 = new Item_Rooms("Executive Room");
        Item_Rooms item3 = new Item_Rooms("Deluxe Room");

        Item_Rooms item4 = new Item_Rooms("GRAND PARAMOUNT BALLROOM");
        Item_Rooms item5 = new Item_Rooms("Ivory Room");
        Item_Rooms item6 = new Item_Rooms("Ivory 2 Room");
     
   
        sub.add(sub1);
        sub.add(sub2);

        sub1.add(item1);
        sub1.add(item2);
        sub1.add(item3);

        sub2.add(item4);
        sub2.add(item5);
        sub2.add(item6);
        
        sub.print();
        
        sub1.print();
    }
}
