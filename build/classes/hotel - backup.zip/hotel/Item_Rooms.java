package hotel;

public class Item_Rooms extends Rooms{
    
    public Item_Rooms(String rm)
	{
		this.Rooms_str = rm;
	}
	
    
}
