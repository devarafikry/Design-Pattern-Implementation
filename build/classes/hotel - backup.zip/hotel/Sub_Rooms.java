package hotel;

import java.util.ArrayList;

public class Sub_Rooms extends Rooms {
    private ArrayList<Rooms> Childs = new ArrayList<>();
	
    public Sub_Rooms(String rm, price){
        this.Rooms_str = rm;
        this.price = price;
        
    }    
	
    public void add(Rooms mn_obj){
        this.Childs.add(mn_obj);
    }
	
    public void remove(Rooms mn_obj){
	this.Childs.remove(mn_obj);
    }
	
    public void print(){
	System.out.println(this.Rooms_str);
	for (Rooms obj_mn : this.Childs) {
            obj_mn.print();
	}
    }
}