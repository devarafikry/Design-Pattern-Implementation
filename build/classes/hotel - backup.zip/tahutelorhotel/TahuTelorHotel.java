package tahutelorhotel;

import hotel.Item_Rooms;
import hotel.Rooms;
import hotel.Sub_Rooms;
import java.util.ArrayList;
import java.util.Scanner;
import tahutelorhotel.creational.Receptionist;
import tahutelorhotel.model.Booking;
import tahutelorhotel.model.Room;

public class TahuTelorHotel {

    static Room[][] room = new Room[2][3];
    static Scanner input = new Scanner(System.in);
    static Receptionist receptionist;
    static ArrayList<Booking> bookings = new ArrayList<Booking>();
    static  Sub_Rooms sub, sub1, sub2;
    
    public static void main(String[] args) { 
//        room[0][0] = new Room("Kamar Tidur Regular",0,300000);
//        room[0][1] = new Room("Kamar Tidur VIP",0,500000);
//        room[0][2] = new Room("Kamar Tidur VVIP",0,1000000);
//        
//        room[1][0] = new Room("Ruang Pertemuan Kecil",1,500000);
//        room[1][1] = new Room("Ruang Pertemuan Sedang",1,2500000);
//        room[1][2] = new Room("Ruang Pertemuan Besar",1,5000000);
        
        HotelRoom();
        printWelcomeMenu();
        printReceptionistMenu();
        System.out.print("Masukkan pilihan ruangan :");
        System.out.println("");
        //initializing factory
        
        
    }
    
    public static void printMenu(int options){
        int userchoice = 77;
        int duration = 77;
        switch(options){
            case 1:
                sub1.print();
                System.out.println("Pilih kamar tidur anda :");
                userchoice = input.nextInt();
                System.out.println("Masukkan durasi booking (hari) :");
                duration = input.nextInt();
                chooseRoom(0,userchoice,duration);
                break;
             case 2:
                sub2.print();
                System.out.println("Pilih ruang pertemuan anda :");
                userchoice = input.nextInt();
                System.out.println("Masukkan durasi booking (hari) :");
                duration = input.nextInt();
                chooseRoom(1,userchoice,duration);
                break;   
             case 3:
                System.out.println("");
                System.out.println("Ini Daftar Pesanan Anda :");
                for (Booking booking: bookings) {
                    System.out.println(booking.getName() +" selama "+booking.getDuration()+" hari, total "+booking.getPrice());
                }
                break;   
        }
        
           
        printWelcomeMenu();
              
        
    }
    
    public static void chooseRoom(int options,int userchoice, int duration){
        System.out.println("nih options "+options);
      
        switch(userchoice){
            case 1:
                bookings.add(receptionist.createBooking(options,room[options][0].getNama(), room[options][0].getPrice(), duration));
                break;
            case 2:
                bookings.add(receptionist.createBooking(options,room[options][1].getNama(), room[options][1].getPrice(), duration));
                break;
            case 3:
                bookings.add(receptionist.createBooking(options,room[options][2].getNama(), room[options][2].getPrice(), duration));
                break;
            case 99:
                printWelcomeMenu();
                break;
        }
        
        System.out.println("Pesanan anda sudah tercatat");
    }
    
    public static void printWelcomeMenu(){
        System.out.println("");
        System.out.println("Tahu Telor Hotel");
        System.out.println("1. Bunyikan bel untuk memanggil resepsionis");
        System.out.println("2. Pergi");
        System.out.println("==================================");
        System.out.print("Masukkan pilihan anda :");
        System.out.println("");
        int options = input.nextInt();
        switch(options){
            case 1:
                receptionist = Receptionist.getInstance();
                printReceptionistMenu();
                break;
            case 2:
                System.out.println("Anda meninggalkan Tahu Telor Hotel");
                break;
            default:
                System.out.println("Anda meninggalkan Tahu Telor Hotel");
        }
    }
    
    public static void printReceptionistMenu(){
        System.out.println("");
        System.out.println("Selamat datang di Tahu Telor Hotel, ada yang bisa saya bantu?");
        System.out.println("1. Pesan Kamar Tidur");
        System.out.println("2. Pesan Ruangan Pertemuan");
        System.out.println("3. Lihat Daftar Pesanan Saya");
        System.out.println("==================================");
        System.out.print("Masukkan pilihan anda :");
        System.out.println("");
        int options = input.nextInt();
        printMenu(options);
    }
    
    
    public static void HotelRoom(){
        sub = new Sub_Rooms("Ruangan");
        sub1 = new Sub_Rooms("Kamar");
        sub2 = new Sub_Rooms("Ruang Rapat");

        Item_Rooms item1 = new Item_Rooms("Suite Room");
        Item_Rooms item2 = new Item_Rooms("Executive Room");
        Item_Rooms item3 = new Item_Rooms("Deluxe Room");

        Item_Rooms item4 = new Item_Rooms("GRAND PARAMOUNT BALLROOM");
        Item_Rooms item5 = new Item_Rooms("Ivory Room");
        Item_Rooms item6 = new Item_Rooms("Ivory 2 Room");
     
        sub.add(sub1);
        sub.add(sub2);

        sub1.add(item1);
        sub1.add(item2);
        sub1.add(item3);

        sub2.add(item4);
        sub2.add(item5);
        sub2.add(item6);
        
    }
}
