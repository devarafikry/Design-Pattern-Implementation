package tahutelorhotel.model;

/**
 *
 * @author Devara Fikry Akmal
 */
public class BedroomBooking extends Booking{

    public BedroomBooking(String name, double price, int duration) {
       super(name,price,duration);
    }

    @Override
    public void setDuration(int duration) {
        super.duration = duration;
    }
    
    
}
