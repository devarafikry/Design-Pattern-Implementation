package hotel;
public class mainKomposisiHotel {
    public static void main(String[] args)
    {
        Sub_Rooms sub = new Sub_Rooms("Ruangan");
        Sub_Rooms sub1 = new Sub_Rooms("Kamar");
        Sub_Rooms sub2 = new Sub_Rooms("Ruang Rapat");
        Sub_Rooms sub3 = new Sub_Rooms("Fasilitas");

        Item_Rooms item1 = new Item_Rooms("Suite Room");
        Item_Rooms item2 = new Item_Rooms("Executive Room");
        Item_Rooms item3 = new Item_Rooms("Deluxe Room");

        Item_Rooms item4 = new Item_Rooms("GRAND PARAMOUNT BALLROOM");
        Item_Rooms item5 = new Item_Rooms("Ivory Room");
        Item_Rooms item6 = new Item_Rooms("Ivory 2 Room");
     
        Item_Rooms item7 = new Item_Rooms("Spa");
        Item_Rooms item8 = new Item_Rooms("Fitness Center");
        Item_Rooms item9 = new Item_Rooms("Swimming Pool");

       
        sub.add(sub1);
        sub.add(sub2);
        sub.add(sub3);

        sub1.add(item1);
        sub1.add(item2);
        sub1.add(item3);

        sub2.add(item4);
        sub2.add(item5);
        sub2.add(item6);
        
        sub3.add(item7);
        sub3.add(item8);
        sub3.add(item9);

        sub.print();
    }
}
