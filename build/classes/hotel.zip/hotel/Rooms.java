package hotel;
public abstract class Rooms {
	String Rooms_str;
	
	public void print()
	{
            System.out.println("   "+Rooms_str);
	}

}
